# CareerSeeker Apple — Handoff Package Manifest

Assembled 2026-08-14 · Fable · For seeding the **CareerSeeker Apple** program:
the `careerseeker-ios` repo and its Claude Project.

## Where each piece goes

| File | Destination | Action |
| --- | --- | --- |
| `01-Apple-Project-Instructions.md` | Claude Project **settings → instructions** | Paste verbatim |
| `02-CareerSeeker-Apple-Handoff.md` | Claude Project **knowledge** | Upload. The authoritative context doc; also commit to the repo as `docs/Apple-Handoff.md` |
| `03-Apple-Progress-Log.md` | Claude Project **knowledge** + repo `docs/` | Upload + commit. Append-only; every session adds a dated entry |
| `04-Seed-Prompts.md` | Your notes | First-session prompts for Fable and Terra in the new project |
| `05-careerseeker-ios-CLAUDE.md` | Repo root, renamed `CLAUDE.md` | Commit. Repo-level agent instructions (distinct from project instructions) |
| `CareerSeeker-CrossPlatform-Roadmap.md` | Claude Project **knowledge** + repo `docs/` | Upload + commit. Planning spec from 2026-07-24; §"superseded" notes in the Handoff apply |
| `CareerSeekerSync-Swift-Evidence.md` | Claude Project **knowledge** + repo `docs/` | Upload + commit. The conformance package's README/evidence doc |
| `conformance-run-2026-08-13.txt` | Repo `docs/evidence/` | Commit. Raw run log, 42/0, corpus digest pinned |
| `careerseeker-ios-sync.tar.gz` | **Repo seed** | Extract at repo root — this becomes the initial commit (SwiftPM package + vendored vectors + CI workflow) |

## What deliberately does NOT move into the new project

Per the seam decision (2026-08-13, this conversation):

- **`docs/Sync-Protocol.md` and `docs/sync-vectors/`** stay in `ShivaClaw/careerseeker`
  as the single normative source. The ios repo carries a *vendored, digest-pinned copy*
  of the vectors (`Vectors/PROVENANCE.md` in the tarball explains the re-vendor rule).
  Do not upload protocol snapshots to project knowledge — agents clone for truth.
- **The PQ ledger** stays in `careerseeker-android`. PQ-IOS-1/2/3 are iOS-*discovered*,
  not iOS-*owned*; one queue, one amendment gate.
- **The macOS engine port (Workstream M)** stays in the main `careerseeker` repo. Same
  .NET code, one engine, multiple RIDs. Only the thin Swift menu-bar shell (M3) lives in
  the Apple repo.

## Project-knowledge upload list, exactly

1. `02-CareerSeeker-Apple-Handoff.md`
2. `03-Apple-Progress-Log.md`
3. `CareerSeeker-CrossPlatform-Roadmap.md`
4. `CareerSeekerSync-Swift-Evidence.md`

Nothing else. Knowledge is orientation; repos are truth. A stale snapshot in project
knowledge that disagrees with the repo is exactly the drift the main repo's `CLAUDE.md`
exists to prevent — don't import the failure mode into the new project.
