# Seed Prompts — CareerSeeker Apple project

Three prompts. The first boots Fable's first session in the new Claude Project. The
second is the Terra/Codex mission preamble for when implementation lanes open. The third
is a re-entry prompt for any later session after a gap. Paste as-is; edit only the
bracketed slots.

---

## Prompt 1 — Fable, first session (orientation + verification)


New project: CareerSeeker Apple. Project knowledge holds the handoff docs; treat them as
orientation, repos as truth.

Orient and verify before anything else:

1. Clone https://github.com/ShivaClaw/careerseeker-ios and
   https://github.com/ShivaClaw/careerseeker fresh. Report HEAD SHAs of both.
2. In careerseeker-ios: run the conformance runner. Report pass/fail counts and the
   corpus digest it prints. Compare the digest against Vectors/PROVENANCE.md and against
   upstream docs/sync-vectors/v1 in the main repo — state explicitly whether the
   vendored copy is current or stale.
3. Re-entry discipline: spot-check three claims from docs/Apple-Progress-Log.md against
   what you can actually observe (e.g. mutation-evidence table vs. the runner, the
   Secure Enclave #if guard, the CI workflow's runner/container). Report each as
   CONFIRMED or DIVERGENT with evidence.
4. State the three PQ-IOS findings from memory of the docs, then verify whether any have
   been resolved upstream (check generate.mjs for the PQ-IOS-3 fix, Sync-Protocol.md §4.3
   for an entitlement_appstore reservation, §7.2 for a malformed code).
5. List the open ADR queue (Handoff §8) and state which are actionable today vs. blocked,
   and on what.

Then stop and give me the state of the program in ten lines or fewer. No new work this
session unless I say so.


## Prompt 2 — Terra/Codex, first implementation lane (preamble)


You are Terra, implementing in ShivaClaw/careerseeker-ios. Read docs/Apple-Handoff.md
and CLAUDE.md at repo root before any code; they bind you.

Standing rules for every lane in this repo:
- swift build -c release and swift run -c release conformance must both succeed with
  exit 0 before any completion claim. Paste the runner's summary block and corpus digest
  into your evidence — a claim without the digest is not evidence.
- Any change to CareerSeekerSync requires either a new corpus vector (filed as a request
  upstream — you do not edit docs/sync-vectors in the main repo) or a new runner check,
  and a mutation demonstrating the check can fail.
- Vectors/ is a vendored copy. Never edit it by hand. If it must move, re-vendor from
  upstream and update PROVENANCE.md + SHA256SUMS in the same commit.
- Do not touch the main repo's src/Sync/, Host.cs, or verifier scripts from this
  program. Protocol questions go to the PQ ledger in careerseeker-android, prefixed
  PQ-IOS-.
- Report executed evidence only. Distinguish MEASURED / DERIVED / UNPROVEN. Anything
  that requires Apple hardware (CryptoKit backend, Secure Enclave, notification
  extension) is UNPROVEN until run there — say so rather than extrapolating from Linux.

Your lane: [LANE DESCRIPTION]. Two-attempt limit; if blocked twice, write the blocker to
docs/Apple-Progress-Log.md and stop.


## Prompt 3 — Any agent, re-entry after a gap


Re-entry, CareerSeeker Apple. Assume nothing from memory is current.

1. Fresh-clone careerseeker-ios; report HEAD and the last three commits.
2. Read the last two entries of docs/Apple-Progress-Log.md; run the conformance runner;
   confirm its output matches the log's most recent claims (counts + digest). Divergence
   is a finding, not a footnote — report it before anything else.
3. Check upstream: has docs/sync-vectors/v1 in ShivaClaw/careerseeker changed since the
   digest in Vectors/PROVENANCE.md? If yes, re-vendoring is the first task regardless of
   what I asked for.
4. Then take up: [TASK].


---

### Notes on using these

- Prompt 1's step 3 exists because "claimed vs. actual is a recurring gap" is the
  program's most-repeated lesson; a new project with fresh memory is exactly where it
  recurs.
- If the `careerseeker-android` bundle is available at first session, append to Prompt 1:
  "Also: audit :core in the bundle for Tink/JVM coupling and draft ADR I1 with a
  recommendation." That is the highest-value blocked item.
- Keep the bracketed lane descriptions small. The repo's CLAUDE.md carries the standing
  rules so prompts don't have to.

